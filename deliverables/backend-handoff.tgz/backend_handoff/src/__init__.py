"""Vehicle memory demo package."""
